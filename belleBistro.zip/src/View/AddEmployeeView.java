package View;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class AddEmployeeView extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public AddEmployeeView() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Employee");
		lblNewLabel.setBounds(250, 11, 138, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(86, 62, 76, 23);
		add(lblNewLabel_1);

	}

}
