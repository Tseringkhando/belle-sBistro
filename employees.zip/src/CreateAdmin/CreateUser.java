package CreateAdmin;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import Model.Users;

public class CreateUser {
// public static void main(String[] args) throws FileNotFoundException {
//	 char[] pass= {'a','d','m','i','n'};
//	    Users adminCredential= new Users("admin",pass,"AD");
//	    
//	    FileOutputStream fos = new FileOutputStream("users.dat");
//	    ObjectOutputStream oos ;
//	    
//		try {
//			oos = new ObjectOutputStream(fos);
//			oos.writeObject(adminCredential);
//			oos.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	  
//	    
//}
}
