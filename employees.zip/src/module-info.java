/**
 * 
 */
/**
 * 
 */
module belleByte {
	requires java.desktop;
}