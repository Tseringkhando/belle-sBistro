package Model;

public class ListEmployeesModel {

}
