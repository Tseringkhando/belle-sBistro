package Model;

public class AddEmployeeModel {

}
